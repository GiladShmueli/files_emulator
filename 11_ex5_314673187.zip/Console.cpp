#include "Console.h"

void Console::run() {
	string exe;
	exe = getAction();		
	while (exe!="exit") {
		try {
			execute_order(exe);
		}
		catch(exception& e){
			cout << e.what() << endl;
		}
		exe = getAction();
	}
}

string Console::getAction(){
	stringstream channel;
	string action;
	command.clear();
	getline(cin, command);
	channel << command;
	channel >> action;
	return action;
}

void Console::execute_order(const string& exe) throw(exception){
	
	if(exe=="read" || exe == "write"){
		read_write(exe);
	}
	else if (exe=="cat" || exe=="head" || exe=="tail"){
		cat_head_tail(exe);
	}
	else if (exe=="move" || exe=="copy"){
		move_copy(exe);
	}
	else if (exe=="remove" || exe=="touch") {
		touch_remove(exe);
	}
	else
	throw UnssportedActionException();
}
// UNARY FUNCTIONS

bool Console::read_write(const string& exe) throw(exception){
	MyRWFile* file;
	string name = getNameFromCommand();
	if(name.empty()) {
		string err = "error: USAGE " + exe + " FILENAME [n].";
		throw WrongUsageException(err);
	}
	command = command.substr(command.find(' ')+1, command.length() );
	if(command.empty()) {
		string err = "error: USAGE " + exe + " FILENAME [n].";
		throw WrongUsageException(err);
	}
	fstream::pos_type pos = getPosFromCommand();
	if(pos < 0) {
		string err = "error: USAGE " + exe + " FILENAME [n].";
		throw WrongUsageException(err);
	}
	file = find_file(name);
	
	if(exe=="read"){
		const char c = (*file)[pos];
		if(c=='\0')
			throw InaccessibleException("error: " + file->getName() + " does not exist or cannot be processed.");
		cout << c << endl;
		return true;
	} 
	if(exe=="write"){
		(*file)[pos] = command.at(command.length()-1);
		return true;
	}
	return false;
}
	
bool Console::cat_head_tail(const string& exe) throw(exception){
	MyRWFile* file;
	string name = getNameFromCommand();
	if(name.empty()) {
		string err = "error: USAGE " + exe + " FILENAME.";
		throw WrongUsageException(err);
	}
	file = find_file(name);
	if(exe=="cat"){
		file->cat();
		return true;
	}
	command = command.substr(command.find(' ')+1, command.length() );
	if(command.empty()) {
		string err = "error: USAGE " + exe + " FILENAME [n].";
		throw WrongUsageException(err);
	}
	int line_num = getLineNumFromCommand();
	if(exe=="head"){
		file->head(line_num);
		return true;
	}
	if(exe=="tail"){
		file->tail(line_num);
		return true;
	}
	return false;
}


bool Console::touch_remove(const string& exe) throw(exception){
	MyRWFile* file;
	string name = getNameFromCommand();
	if(name.empty()) {
		string err = "error: USAGE " + exe + " FILENAME.";
		throw WrongUsageException(err);
	}
	file = find_file(name);
	 if(exe=="touch"){
		file->touch();
		file->touch();//for some reason works this way when you open an existing file first time
		return true;
	}
	if(exe=="remove"){
		file->remove();
		return true;
	}
	return false;
}
// BINARY FUNCTIONS
bool Console::move_copy(const string& exe) throw(exception){
	stringstream channel;
	string src, dest;
	string err = "error: USAGE " + exe + " SOURCE_FILENAME TARGET_FILENAME";
	src = getNameFromCommand();
	if(src.empty()) {
		throw WrongUsageException(err);
	}
	dest = getNameFromCommand();
	if(dest.empty()) {
		throw WrongUsageException(err);
	}
	MyRWFile src_file = *find_file(src);
	MyRWFile dest_file = *find_file(dest);
	if(exe=="move"){
		MyRWFile::move(src_file,dest_file);
		return true;
	} 
	if(exe=="copy"){
		MyRWFile::copy(src_file,dest_file);
		return true;
	}
	return false;
}


string Console::getNameFromCommand(){
	stringstream channel;
	string name;
	command = command.substr(command.find(' ')+1, command.length() );
	channel << command;
	channel >> name;
	return name;
}

fstream::pos_type Console::getPosFromCommand(){
		stringstream channel;
		int pos = -1;
		
		channel << command;
		channel >> pos;

		return pos;
}

int Console::getLineNumFromCommand(){
	stringstream channel;
	int pos = -1;
	command = command.substr(command.find(' ')+1, command.length() );
	if(!command.empty()) {
		channel << command;
		channel >> pos;
	}
	return pos;
}

void Console::print_commands() {
	cout << "[1] read FILENAME POSITION" << endl;
	cout << "[2] write FILENAME POSITION CHARACTER" << endl;
	cout << "[3] touch FILENAME" << endl;
	cout << "[4] copy SOURCE_FILENAME TARGET_FILENAME" << endl;
	cout << "[5] remove FILENAME" << endl;
	cout << "[6] move SOURCE_FILENAME TARGET_FILENAME" << endl;
	cout << "[7] cat FILENAME" << endl;
	cout << "[8] head FILENAME [n]" << endl;
	cout << "[9] tail FILENAME [n]" << endl;
	cout << "[10] exit" << endl;  
}