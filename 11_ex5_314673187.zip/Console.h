#ifndef CONSOLE_H
#define CONSOLE_H
#include <iostream>
#include <vector>
#include <sstream>
#include "MyRWFile.h"
#include "my_exceptions.h"
using namespace std;

class Console{
	string command;
	vector<MyRWFile*> files;
	
	string getAction();
	bool read_write(const string& exe) throw(exception);
	bool cat_head_tail(const string& exe) throw(exception);
	bool touch_remove(const string& exe) throw(exception);
	bool move_copy(const string& exe) throw(exception);
	
	
	string getNameFromCommand();
	fstream::pos_type getPosFromCommand();
	int getLineNumFromCommand();
	
	public:
    static void print_commands();
	void execute_order(const string& exe) throw(exception);
	void run();
	
	MyRWFile* find_file(const string& to_find){
		
		MyRWFile* temp;
		int size = files.size();
		for(int i=0; i<size ; ++i) {
			temp = files[i];
			if(temp->getName() == to_find)
				return temp;
		}
		fstream* file(new fstream(to_find.c_str()));
		temp = new MyRWFile(*file, to_find);
		files.push_back(temp);
		return temp;
	}
	MyRWFile* open_rwfile(const string& name){
		fstream low_file(name.c_str());
		MyRWFile *rw_file = new MyRWFile(low_file, name);
		files.push_back(rw_file);
		return rw_file;
	}
	
	~Console() {
		
	}
};

#endif