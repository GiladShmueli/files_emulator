#include "MyRWFile.h"

const char MyRWFile::operator[](const fstream::pos_type index) const throw(InaccessibleException){
	if (index<0 || index>length()+1)
		throw InaccessibleException("error: " + name + " does not exist or cannot be processed.");
    CharProxy result(file, index);
    return result;
}

MyRWFile& MyRWFile::copy(MyRWFile& source, MyRWFile& destination){
	
	char tc;
    destination.remove();
	ofstream temp(destination.name.c_str());
	//source.cat(destination.file);
	source.file.seekg(ios_base::beg);
	tc = source.file.get();
	while(tc!=EOF) {
		temp << tc;
		tc = source.file.get();
	}
	temp.close();
	destination.file.open(destination.name.c_str());

	return destination;
}

void MyRWFile::touch(){
	char c;
	if(!file) {
		file.open(name.c_str(), std::fstream::in | std::fstream::out | std::fstream::app);
	}
	//TODO change timestamp
	
	file >> c;
	file.seekg(ios_base::beg);
	file << c;
}

void MyRWFile::remove(){
	file.close();
	std::remove(name.c_str());
}

void MyRWFile::cat(){
	char c;
	file.seekg(ios_base::beg);
	while(file.get(c)){
		cout << c;
	}
	cout << endl;
}

void MyRWFile::head(int n){
	int cnt=0;
	char tp;
	file.seekg(ios_base::beg);
	while(cnt<n && !file.eof()) {
		tp = file.get();
		cout << tp;
		if (tp=='\n')
			cnt++;
	}
		
}

void MyRWFile::tail(int n){
	int cnt=0;
	char tp[LINE_LENGTH];
	queue<string> lines;
	file.seekg(ios_base::beg);
	while(!file.eof()) {
		file.getline(tp, LINE_LENGTH);
		lines.push(tp);
		cnt++;
	}
	while(cnt>n) {
		lines.pop();
		cnt--;
	}
	while(!lines.empty()) {
		cout << lines.front() << endl;
		lines.pop();
		cnt++;
	}
}

MyRWFile& MyRWFile::move(MyRWFile& source, MyRWFile& destination){
	MyRWFile::copy(source, destination);
	source.remove();
	return destination;
}