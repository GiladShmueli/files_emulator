#ifndef MY_FILE
#define MY_FILE
#include <iostream>
#include <fstream>
#include <cstdlib>
#include <queue>
#include "my_exceptions.h"
using namespace std;
const int LINE_LENGTH=256;

class MyRWFile {
    fstream& file;
	string name;

    public:
    MyRWFile(std::fstream &f, string nm): file(f), name(nm){ }
	//cpy c'tor + operator= can be default
	
    class CharProxy { //Nested class
        fstream& file_;
        fstream::pos_type pos_;
        public:
        CharProxy(fstream &file, fstream::pos_type pos) :
            file_(file), pos_(pos) {}
            CharProxy& operator=(char c) {
            file_.seekp(pos_);
			if(file_.peek() == -1){
				file_.seekg (0, file_.end);	
				file_.seekg(file_.tellg());
				file_.write(" ",1);
				file_.seekp(pos_);
				cout << file_.peek();
			}
            file_.put(c);
            return *this;
        }
        operator char() {
            file_.seekg(pos_);
            return char(file_.get());
        }
    };

    const char operator[](const fstream::pos_type index) const throw(InaccessibleException);
    MyRWFile::CharProxy& operator[](const fstream::pos_type index) throw(InaccessibleException){

		if (index<0 || index>length()+1)
			throw InaccessibleException("error: " + name + " does not exist or cannot be processed.");
        CharProxy* result= new CharProxy(file,index);
        return *result;
    }
	int length() const{
		file.seekg (0, file.end);
		return file.tellg();
	}
	void touch();
    static MyRWFile& copy(MyRWFile& source, MyRWFile& destination);
	void remove();
	static MyRWFile& move(MyRWFile& source, MyRWFile& destination);
	void cat(); //print all
	void head(int n=10);
	void tail(int n=10);
	string getName() const{ return name;}
	bool not_exists(){ return !file;}
    ~MyRWFile(){file.close();} //that is my only worry about closing.
};

#endif