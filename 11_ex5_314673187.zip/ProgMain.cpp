#include <iostream>
#include "Console.h"
#include "MyRWFile.h"

int main(void){
    Console console;
	console.run();

	
    return 0;
}