#ifndef MY_EXCEPTIONS
#define MY_EXCEPTIONS
#include <exception>
using std::exception;

class InaccessibleException: public exception{
	const char* error;
	public:
	InaccessibleException(const char*& err): error(err){ }
	InaccessibleException(const std::string& err): error(err.c_str()){ }
	virtual const char* what() const throw(){
		return error;
	}
};

class UnssportedActionException: public exception{
	
	public:
	virtual const char* what() const throw(){
		return "error: command is not supported.";
	}
};

class WrongUsageException: public exception{
	//error: USAGE tail FILENAME [n].\n
	const char* error;
	public:
	WrongUsageException(const char*& err): error(err){ }
	WrongUsageException(const std::string& err): error(err.c_str()){ }
	
	virtual const char* what() const throw(){
		return error;
	}
};




#endif